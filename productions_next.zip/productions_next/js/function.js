
$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});

var swiper = new Swiper(".work_slider_main", {
    slidesPerView: 1,
    spaceBetween: 15,
	centeredSlides: true,
	loop: true,
	speed: 500,
	loop: true,
	// autoplay: {
	// 	delay: 4000,
	// 	disableOnInteraction: false,
	// },
	navigation: {
        nextEl: ".slider_btn_next",
        prevEl: ".slider_btn_prev",
    },
	breakpoints: {
        400: {
          slidesPerView: 3,
		  spaceBetween: 15,
        },
    }

});

var swiper = new Swiper(".serve_slider_main", {
    slidesPerView: 3,
    spaceBetween: 15,
	centeredSlides: true,
	loop: true,
	speed: 500,
	loop: true,
	// autoplay: {
	// 	delay: 4000,
	// 	disableOnInteraction: false,
	// },
	navigation: {
        nextEl: ".slider_btn_next1",
        prevEl: ".slider_btn_prev1",
    }
});

var swiper = new Swiper(".benefits_slider_main", {
    slidesPerView: 1,
    spaceBetween: 15,
	loop: true,
	speed: 500,
	loop: true,
	// autoplay: {
	// 	delay: 4000,
	// 	disableOnInteraction: false,
	// },
	navigation: {
        nextEl: ".slider_btn_next1",
        prevEl: ".slider_btn_prev1",
    },
	breakpoints: {
        400: {
          slidesPerView: 1.5,
		  spaceBetween: 15,
        },
        768: {
            slidesPerView: 1.5,
			spaceBetween: 15,
        },
    }
});


$(window).scroll(function(){
	var sticky = $('header'),
	scroll = $(window).scrollTop();
	if (scroll >= 150){
		sticky.addClass('fixed_header');
		$('body').css("", header_height);
	}
	else {
		sticky.removeClass('fixed_header');
	  $('body').css("", "0");
	  }
  });
