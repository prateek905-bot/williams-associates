
$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});

$(window).scroll(function(){
	var sticky = $('header'),
	scroll = $(window).scrollTop();
	if (scroll >= 150){
		sticky.addClass('fixed_header');
		$('body').css("", header_height);
	}
	else {
		sticky.removeClass('fixed_header');
	  $('body').css("", "0");
	  }
  });

  var swiper = new Swiper(".ini_slider", {
    slidesPerView: 3,
    spaceBetween: 20,
    navigation: {
        nextEl: ".slider_btn_next",
        prevEl: ".slider_btn_prev",
    },
	speed: 500,
	loop: true,
	autoplay: {
	  delay: 5000,
	  disableOnInteraction: false,
	},
  breakpoints: {
  300: {
    slidesPerView: 1,
    spaceBetween: 15,
    },
      400: {
        slidesPerView: 1,
    spaceBetween: 20,
      },
      768: {
          slidesPerView: 2,
    spaceBetween: 20,
      },
      1024: {
          slidesPerView: 3,
      },
    }
});

var swiper = new Swiper(".cpm_slider", {
  slidesPerView: 3,
  spaceBetween: 30,
  navigation: {
      nextEl: ".slider_btn_next",
      prevEl: ".slider_btn_prev",
  },
speed: 500,
loop: true,
autoplay: {
  delay: 5000,
  disableOnInteraction: false,
},
breakpoints: {
300: {
  slidesPerView: 1,
  spaceBetween: 15,
  },
    400: {
      slidesPerView: 1,
  spaceBetween: 20,
    },
    768: {
        slidesPerView: 2,
  spaceBetween: 20,
    },
    1024: {
        slidesPerView: 3,
    },
  }
});