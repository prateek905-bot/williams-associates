
$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});

$(window).scroll(function(){
	var sticky = $('header'),
	scroll = $(window).scrollTop();
	if (scroll >= 150){
		sticky.addClass('fixed_header');
		$('body').css("", header_height);
	}
	else {
		sticky.removeClass('fixed_header');
	  $('body').css("", "0");
	  }
  });
