$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});




$(document).ready(function(){
	$('.h_height').matchHeight();
});